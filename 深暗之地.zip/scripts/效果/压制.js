const 压制 = new status("压制");
exports.压制 = 压制;